# Scudo anti-truffe (Android)

1. Apri questa cartella con Android Studio (Hedgehog o più recente) e attendi la sincronizzazione di Gradle.
2. Collega un telefono Android 10+ (debug USB attivo) o avvia un emulatore e premi Run.
3. Per un file installabile: Build > Build Bundle(s) / APK(s) > Build APK(s).

L'app non ha il permesso INTERNET: il testo analizzato resta sul telefono.
La pagina dell'app e' in app/src/main/assets/index.html.
